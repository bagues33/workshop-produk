<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <!-- Notifikasi menggunakan flash session data -->
        <?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="card border-0 shadow rounded">
            <div class="card-body">
                <a href="<?php echo e(route('kategori-produk.create')); ?>" class="btn btn-md btn-success mb-3 float-right">Tambah Kategori</a>

                <table class="table table-bordered mt-1">
                    <thead>
                        <tr>
                            <th class="text-center">Nama Kategori</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($value->nama_kategori); ?></td>
                                <td class="text-center">
                                    <form onsubmit="return confirm('Apakah Anda Yakin ?');"
                                        action="<?php echo e(route('kategori-produk.delete', $value->id)); ?>" method="GET">
                                        <a href="<?php echo e(route('kategori-produk.edit', $value->id)); ?>" class="btn btn-sm btn-primary">EDIT</a>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-sm btn-danger">HAPUS</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td class="text-center text-mute" colspan="2">Data Kategori tidak tersedia</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/projectkebayamerah/projectworkshop/resources/views/kategori/index.blade.php ENDPATH**/ ?>